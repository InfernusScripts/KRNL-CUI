-- KRNL by @infernusx | Synapse Z Custom UI
print("Hello, World!")
getgenv().identifyexecutor = function()
	return __OLD[1], __OLD[2]
end